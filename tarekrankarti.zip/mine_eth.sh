#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=ssl://eu1.ethermine.org:5555
WALLET=0xe1b21ee4f8fe4fbb1deb961115d4435434f57ac3.lolMinerWorker1

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
done
