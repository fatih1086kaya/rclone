./chia_plot -n -1 -r 12 -u 256 -t /root/temp/ -d /root/plor/ -c xch1r7a7nxcr92ups3eevemwgns49kqg423sflmn4ge7lqlaylxcdksq5ky9xd -f 91612b26f7a980002dc6ba52052ad3875082e04adbcd2ff5cfd9d6ead9992da1c5610feff5f22d79670b9c362ad6bd40

