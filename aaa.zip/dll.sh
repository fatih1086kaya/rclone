cd
dpkg --configure -a
sudo apt-get update

sudo apt-get upgrade -y

sudo apt install git -y

apt install unzip

cd
wget https://downloads.rclone.org/v1.57.0/rclone-v1.57.0-linux-amd64.deb
sudo dpkg -i rclone-v1.57.0-linux-amd64.deb

rclone config



sudo apt install -y libsodium-dev cmake g++ git build-essential

sudo apt-get install build-essential cmake

mkdir madmax
cd madmax
git clone https://github.com/madMAx43v3r/chia-plotter.git

cd chia-plotter


git submodule update --init
./make_devel.sh

cd build

apt install screen

screen -R plor

