#pragma once

#include <string>

const std::string kVersion = "1.1.7" "-" GIT_COMMIT_HASH;
