#!/bin/bash
while [ true ]
do
  echo "Basladi"
  for file in /ssd2/*.plot
  do
         rclone move /ssd2/ gdrive:temp --ignore-existing --drive-chunk-size 1024M  --fast-list -vv --no-traverse --include "/*.plot" --checkers 3 --tpslimit 3 --transfers 3 --drive-server-side-across-configs -P
      sleep 60
  done
  sleep 60
done

